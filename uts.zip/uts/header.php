<!DOCTYPE html>
<<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title;?></title>
	<link href="style.css" rel="stylesheet"
type="text/css"/>
</head>
<body>
	<div class="container">
			<h1>Data Barang</h1>
			</div class="main">